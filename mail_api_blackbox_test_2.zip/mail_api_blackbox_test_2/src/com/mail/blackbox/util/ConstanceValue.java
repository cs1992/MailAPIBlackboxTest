package com.mail.blackbox.util;

public class ConstanceValue {

	public static final String OPTION_TEST_CONTROLLER = "optionTest";
}
