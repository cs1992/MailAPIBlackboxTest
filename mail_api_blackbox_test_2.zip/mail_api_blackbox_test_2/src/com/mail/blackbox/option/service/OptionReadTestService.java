package com.mail.blackbox.option.service;

public interface OptionReadTestService {

}
