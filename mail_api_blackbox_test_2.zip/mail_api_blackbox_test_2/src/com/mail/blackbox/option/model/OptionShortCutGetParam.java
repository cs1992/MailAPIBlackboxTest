package com.mail.blackbox.option.model;

import com.mail.blackbox.dto.Param;

public class OptionShortCutGetParam extends Param  {
	private Param shorCut;

	public Param getShorCut() {
		return shorCut;
	}

	public void setShorCut(Param shorCut) {
		this.shorCut = shorCut;
	}
	
	
}
