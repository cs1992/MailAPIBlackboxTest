package com.mail.blackbox.option.model;

import com.mail.blackbox.dto.Param;

public class OptionTrashGetParam extends Param  {

}
