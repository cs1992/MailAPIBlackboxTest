package com.mail.blackbox.dto;

import java.util.HashMap;

public class Param {
	protected HashMap<String, Object> params;

	public HashMap<String, Object> getParams() {
		return params;
	}

	public void setParams(HashMap<String, Object> params) {
		this.params = params;
	}

}
